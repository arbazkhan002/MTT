iitk-thesis-format
==================

Latex Document class for iitk thesis according to DoAA recommendation
