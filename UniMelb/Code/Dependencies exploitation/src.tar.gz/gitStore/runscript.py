import os

for i in range(1,39):
	j=i
	if i<10:
		i="0"+str(i)
	#~ os.system("mv /home/arbazk/MTT/UniMelb/newData/campus"+str(j)+".txt"+"/home/arbazk/MTT/UniMelb/newData/campus"+str(i)+".txt")
	os.system("./triplet.sh "+str(i))
